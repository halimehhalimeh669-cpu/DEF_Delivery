# خطوات تفعيل Firebase لمرة واحدة — DEF Delivery

تم تجهيز المشروع بملف `google-services.json` وبـ Firebase Anonymous Auth وCloud Firestore. يلزم تنفيذ هاتين الخطوتين داخل حساب Firebase الخاص بمالك المشروع لأن أدوات البناء لا تملك صلاحية الدخول إلى حسابك:

1. افتح Firebase Console ثم مشروع `def-delivery`.
2. من Build > Authentication > Get started > Sign-in method فعّل **Anonymous** ثم Save.
3. من Build > Firestore Database > Create database أنشئ قاعدة البيانات. اختر موقعاً مناسباً لمستخدميك وابدأ بوضع Production.
4. بعد الإنشاء افتح تبويب Rules، وانسخ محتوى الملف `firestore.rules` ثم اضغط Publish.
5. افتح المشروع في Android Studio، ثم Sync Project with Gradle Files، وبعدها Build > Build Bundle(s) / APK(s) > Build APK(s).

بعدها، عند تأكيد الطلب من التطبيق، سيُحفظ في مجموعة `deliveryRequests` بحالة `pending`.

## حدود النسخة الحالية
لا توجد لوحة إدارة أو حسابات سائقين أو توزيع تلقائي أو إشعارات أو تتبع مباشر أو دفع إلكتروني. مفاتيح Firebase الموجودة في `google-services.json` هي إعدادات تطبيق Android وليست بديلاً عن قواعد Firestore الآمنة.

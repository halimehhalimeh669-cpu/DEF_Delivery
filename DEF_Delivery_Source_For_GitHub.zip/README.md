# DEF Delivery — Android project

Bilingual Arabic/English Android customer app prototype.

## Included in this iteration
- DEF Delivery branding and Arabic RTL / English LTR language toggle.
- Delivery categories: restaurants and food, shopping and general errands, parcels and other items.
- Delivery fees: Aley & Aley District $1.50; Baabda & Baabda District $3.00; Beirut $4.00.
- Customer request form for name, phone, pickup address, delivery address, and optional notes.
- Required-field validation and a local order-review dialog.

## Important functional limitation
The request form now uses Firebase Anonymous Authentication and Cloud Firestore. After the customer confirms, the app writes a document to `deliveryRequests` with status `pending`. The included `firestore.rules` restricts reads to the submitting installation's anonymous user and disallows edits/deletes.

**One-time Firebase Console steps are still required in the owner's account:** enable Authentication > Sign-in method > Anonymous; create Cloud Firestore in production mode; publish the included `firestore.rules`. Until these steps are completed, order submission will fail with a Firebase configuration/permission message. No driver dispatch, admin dashboard, notifications, live tracking, or payment integration is included.

## Build and release
Open this folder in Android Studio and sync Gradle. Generate a signed Android App Bundle (AAB) with your own upload key after configuring release signing. Complete Google Play Console testing, store listing, privacy policy, data safety, and all applicable declarations before publishing. Do not publish a debug build.

# بناء APK لتطبيق DEF Delivery

1. ارفع محتويات هذا المشروع إلى مستودع GitHub جديد (يجب أن يكون مجلد `defdelivery_work` هو جذر المستودع، وليس مجلداً داخلياً).
2. افتح تبويب **Actions** في GitHub.
3. اختر **Build DEF Delivery APK** ثم اضغط **Run workflow**.
4. بعد انتهاء البناء بنجاح، افتح نتيجة التشغيل ونزّل الملف من **Artifacts** باسم `DEF-Delivery-debug-APK`.
5. فك الضغط عن الملف المنزّل، ثم ثبّت `app-debug.apk` على هاتف Android.

## ملاحظات مهمة
- هذا APK تجريبي موقّع بمفتاح debug، وليس إصداراً جاهزاً للنشر على Google Play.
- إرسال الطلبات إلى Firebase يتطلب تفعيل **Authentication > Anonymous** وإنشاء Cloud Firestore ونشر قواعد `firestore.rules` الموجودة في المشروع.
- ملف إعداد Firebase الموجود بالمشروع يجب أن يكون تابعاً لمشروع Firebase الذي تملكه.
- قبل النشر على Google Play يلزم إعداد مفتاح توقيع release وإنتاج AAB، إضافة إلى استكمال صفحة المتجر وسياسة الخصوصية وتصريحات Google Play.

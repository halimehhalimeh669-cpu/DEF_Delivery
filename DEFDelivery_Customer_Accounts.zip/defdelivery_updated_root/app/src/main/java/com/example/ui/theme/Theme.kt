package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val BlackGoldScheme = darkColorScheme(
    primary = Color(0xFFFFD700),
    onPrimary = Color(0xFF090909),
    secondary = Color(0xFFD4AF37),
    onSecondary = Color(0xFF090909),
    tertiary = Color(0xFFFFE08A),
    background = Color(0xFF0A0A0A),
    onBackground = Color(0xFFF5F5F5),
    surface = Color(0xFF171717),
    onSurface = Color(0xFFF5F5F5),
    surfaceVariant = Color(0xFF242424),
    onSurfaceVariant = Color(0xFFE0E0E0),
    outline = Color(0xFF8A7430)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(colorScheme = BlackGoldScheme, typography = Typography, content = content)
}

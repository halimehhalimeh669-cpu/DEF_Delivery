package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

private val Navy = Color(0xFFFFD700) // premium gold
private val Orange = Color(0xFFD4AF37) // metallic gold
private val Pale = Color(0xFF242424) // charcoal divider

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MyApplicationTheme { DEFDeliveryApp() } }
    }
}

private data class DeliveryArea(val en: String, val ar: String, val price: String)
private data class DeliveryService(val en: String, val ar: String, val emoji: String)

@Composable
fun DEFDeliveryApp() {
    var arabic by remember { mutableStateOf(false) }
    var selectedArea by remember { mutableIntStateOf(0) }
    var selectedService by remember { mutableIntStateOf(0) }
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var pickupAddress by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }
    var orderNotes by remember { mutableStateOf("") }
    var showOrderPreview by remember { mutableStateOf(false) }
    var formError by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var submissionMessage by remember { mutableStateOf("") }
    var orderHistory by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var historyMessage by remember { mutableStateOf("") }
    var isLoadingHistory by remember { mutableStateOf(false) }
    var customerSignedIn by remember {
        mutableStateOf(
            FirebaseAuth.getInstance().currentUser?.email?.let {
                !it.equals("halimehhalimeh669@gmail.com", ignoreCase = true)
            } == true
        )
    }
    var adminMode by remember { mutableStateOf(false) }
    var adminEmail by remember { mutableStateOf("") }
    var adminPassword by remember { mutableStateOf("") }
    var adminMessage by remember { mutableStateOf("") }
    var adminLoading by remember { mutableStateOf(false) }
    var adminOrders by remember { mutableStateOf<List<Map<String, String>>>(emptyList()) }
    var adminListener by remember { mutableStateOf<ListenerRegistration?>(null) }

    val areas = listOf(
        DeliveryArea("Aley & Aley District", "عاليه وقضاء عاليه", "$1.50"),
        DeliveryArea("Baabda & Baabda District", "بعبدا وقضاء بعبدا", "$3.00"),
        DeliveryArea("Beirut", "بيروت", "$6.00"),
        DeliveryArea("Shouf & Chouf District", "الشوف", "$6.00")
    )
    val services = listOf(
        DeliveryService("Restaurants & food", "مطاعم وأكل", "🍔"),
        DeliveryService("Shopping & everything", "تسوّق وكل شي", "🛍️"),
        DeliveryService("Parcels & other items", "طرود وأغراض مختلفة", "📦")
    )
    val direction = if (arabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        Surface(color = Color(0xFF0A0A0A), modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("DEFDelivery", color = Navy, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
                        Text(if (arabic) "خدمة التوصيل" else "DELIVERY SERVICE", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    }
                    TextButton(onClick = { arabic = !arabic }) {
                        Text(if (arabic) "English" else "العربية", color = Navy, fontWeight = FontWeight.Bold)
                    }
                    TextButton(onClick = {
                        if (adminMode) {
                            adminListener?.remove()
                            adminListener = null
                            FirebaseAuth.getInstance().signOut()
                            adminMode = false
                            adminPassword = ""
                            adminOrders = emptyList()
                            adminMessage = ""
                        } else {
                            adminMode = true
                            adminMessage = ""
                        }
                    }) {
                        Text(if (adminMode) { if (arabic) "رجوع" else "Back" }
                             else { if (arabic) "الإدارة" else "Admin" },
                            color = Navy, fontWeight = FontWeight.Bold)
                    }
                }

                if (adminMode) {
                    AdminDashboard(
                        arabic = arabic,
                        email = adminEmail,
                        onEmailChange = { adminEmail = it },
                        password = adminPassword,
                        onPasswordChange = { adminPassword = it },
                        message = adminMessage,
                        loading = adminLoading,
                        orders = adminOrders,
                        onLogin = {
                            if (adminEmail.isBlank() || adminPassword.isBlank()) {
                                adminMessage = if (arabic) "أدخل البريد الإلكتروني وكلمة المرور." else "Enter your email and password."
                            } else {
                                adminLoading = true
                                adminMessage = ""
                                FirebaseAuth.getInstance()
                                    .signInWithEmailAndPassword(adminEmail.trim(), adminPassword)
                                    .addOnSuccessListener { result ->
                                        val user = result.user
                                        if (user?.email.equals("halimehhalimeh669@gmail.com", ignoreCase = true)) {
                                            if (user?.isEmailVerified == true) {
                                            adminListener?.remove()
                                            adminListener = FirebaseFirestore.getInstance().collection("deliveryRequests")
                                                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                                                .addSnapshotListener { snapshot, error ->
                                                    adminLoading = false
                                                    if (error != null) {
                                                        adminMessage = error.localizedMessage ?: "Could not load orders."
                                                    } else if (snapshot != null) {
                                                        adminOrders = snapshot.documents.map { doc ->
                                                            mapOf(
                                                                "id" to doc.id,
                                                                "name" to (doc.getString("customerName") ?: ""),
                                                                "phone" to (doc.getString("customerPhone") ?: ""),
                                                                "service" to (doc.getString("service") ?: ""),
                                                                "area" to (doc.getString("area") ?: ""),
                                                                "fee" to (doc.getString("deliveryFee") ?: ""),
                                                                "pickup" to (doc.getString("pickupAddress") ?: ""),
                                                                "delivery" to (doc.getString("deliveryAddress") ?: ""),
                                                                "notes" to (doc.getString("notes") ?: ""),
                                                                "status" to (doc.getString("status") ?: "pending")
                                                            )
                                                        }
                                                        adminMessage = if (adminOrders.isEmpty()) { if (arabic) "ما في طلبات بعد." else "No orders yet." } else ""
                                                    }
                                                }
                                            } else {
                                                user?.sendEmailVerification()?.addOnCompleteListener { task ->
                                                    FirebaseAuth.getInstance().signOut()
                                                    adminLoading = false
                                                    adminMessage = if (task.isSuccessful) {
                                                        if (arabic) "بعتنالك رسالة تأكيد على بريدك. أكّد البريد وارجع سجّل الدخول." else "We sent a verification email. Verify it, then sign in again."
                                                    } else {
                                                        task.exception?.localizedMessage ?: "Could not send verification email."
                                                    }
                                                }
                                            }
                                        } else {
                                            FirebaseAuth.getInstance().signOut()
                                            adminLoading = false
                                            adminMessage = if (arabic) "هذا الحساب غير مخوّل. استخدم بريد الإدارة الصحيح." else "This account is not authorized. Use the correct admin email."
                                        }
                                    }
                                    .addOnFailureListener { error ->
                                        adminLoading = false
                                        adminMessage = error.localizedMessage ?: "Sign-in failed."
                                    }
                            }
                        },
                        onRefresh = {
                            adminLoading = true
                            FirebaseFirestore.getInstance().collection("deliveryRequests")
                                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                                .get()
                                .addOnSuccessListener { snapshot ->
                                    adminOrders = snapshot.documents.map { doc ->
                                        mapOf(
                                            "id" to doc.id,
                                            "name" to (doc.getString("customerName") ?: ""),
                                            "phone" to (doc.getString("customerPhone") ?: ""),
                                            "service" to (doc.getString("service") ?: ""),
                                            "area" to (doc.getString("area") ?: ""),
                                            "fee" to (doc.getString("deliveryFee") ?: ""),
                                            "pickup" to (doc.getString("pickupAddress") ?: ""),
                                            "delivery" to (doc.getString("deliveryAddress") ?: ""),
                                            "notes" to (doc.getString("notes") ?: ""),
                                            "status" to (doc.getString("status") ?: "pending")
                                        )
                                    }
                                    adminLoading = false
                                    adminMessage = if (adminOrders.isEmpty()) { if (arabic) "ما في طلبات بعد." else "No orders yet." } else ""
                                }
                                .addOnFailureListener { error ->
                                    adminLoading = false
                                    adminMessage = error.localizedMessage ?: "Could not load orders."
                                }
                        },
                        onStatusChange = { orderId, newStatus ->
                            FirebaseFirestore.getInstance().collection("deliveryRequests").document(orderId)
                                .update("status", newStatus)
                                .addOnSuccessListener {
                                    adminOrders = adminOrders.map { order ->
                                        if (order["id"] == orderId) order + ("status" to newStatus) else order
                                    }
                                }
                                .addOnFailureListener { error -> adminMessage = error.localizedMessage ?: "Could not update order." }
                        }
                    )
                } else {
                CustomerAccountPanel(
                    arabic = arabic,
                    signedIn = customerSignedIn,
                    onSignedIn = { customerSignedIn = true },
                    onSignOut = {
                        FirebaseAuth.getInstance().signOut()
                        customerSignedIn = false
                        orderHistory = emptyList()
                        historyMessage = ""
                    }
                )
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (arabic) "منطلبلك… ومنوصّلك!" else "You order it. We deliver it.",
                            color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        Text(if (arabic) "توصيل مطاعم، تسوّق، طرود وكل شي بتحتاجه."
                             else "Restaurants, shopping, parcels and everything you need.",
                            color = Color(0xFFDCE6F2), fontSize = 14.sp)
                        Text(if (arabic) "توصيل سريع • أسعار واضحة" else "Fast delivery • Clear prices",
                            color = Orange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                SectionTitle(if (arabic) "اختار المنطقة" else "Choose your delivery area")
                areas.forEachIndexed { index, area ->
                    SelectableRow(
                        title = if (arabic) area.ar else area.en,
                        subtitle = if (arabic) "رسوم التوصيل" else "Delivery fee",
                        trailing = area.price,
                        selected = selectedArea == index,
                        onClick = { selectedArea = index }
                    )
                }

                SectionTitle(if (arabic) "شو بدك نوصّلك؟" else "What do you need delivered?")
                services.forEachIndexed { index, service ->
                    SelectableRow(
                        title = "${service.emoji}  " + if (arabic) service.ar else service.en,
                        subtitle = if (arabic) "اطلب من أي محل أو مطعم" else "Order from any shop or restaurant",
                        trailing = if (selectedService == index) "✓" else "",
                        selected = selectedService == index,
                        onClick = { selectedService = index }
                    )
                }

                SectionTitle(if (arabic) "تفاصيل الطلب" else "Order details")
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = customerName, onValueChange = { customerName = it },
                            label = { Text(if (arabic) "الاسم الكامل" else "Full name") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true
                        )
                        OutlinedTextField(
                            value = customerPhone, onValueChange = { customerPhone = it },
                            label = { Text(if (arabic) "رقم الهاتف" else "Phone number") },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Phone)
                        )
                        OutlinedTextField(
                            value = pickupAddress, onValueChange = { pickupAddress = it },
                            label = { Text(if (arabic) "عنوان الاستلام / المطعم / المتجر" else "Pickup / restaurant / shop address") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = deliveryAddress, onValueChange = { deliveryAddress = it },
                            label = { Text(if (arabic) "عنوان التوصيل" else "Delivery address") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = orderNotes, onValueChange = { orderNotes = it },
                            label = { Text(if (arabic) "ملاحظات إضافية (اختياري)" else "Extra notes (optional)") },
                            modifier = Modifier.fillMaxWidth(), minLines = 2
                        )
                        if (formError) {
                            Text(
                                if (arabic) "يرجى تعبئة الاسم والهاتف وعنوانَي الاستلام والتوصيل."
                                else "Please enter your name, phone, pickup address and delivery address.",
                                color = MaterialTheme.colorScheme.error, fontSize = 12.sp
                            )
                        }
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (arabic) "ملخّص التوصيل" else "Delivery summary",
                            color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (arabic) "المنطقة" else "Area", color = Color(0xFFDDDDDD))
                            Text(if (arabic) areas[selectedArea].ar else areas[selectedArea].en,
                                color = Navy, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (arabic) "رسوم التوصيل" else "Delivery fee", color = Color(0xFFDDDDDD))
                            Text(areas[selectedArea].price, color = Orange, fontWeight = FontWeight.Black, fontSize = 20.sp)
                        }
                        Divider(color = Pale)
                        Text(
                            if (arabic) "السعر المعروض هو رسم التوصيل للمنطقة المختارة. سعر المنتجات أو الطلب يُدفع بشكل منفصل."
                            else "The displayed amount is the delivery fee for the selected area. Items/order cost is paid separately.",
                            color = Color(0xFFBDBDBD), fontSize = 12.sp
                        )
                    }
                }

                Button(
                    onClick = {
                        formError = customerName.isBlank() || customerPhone.isBlank() ||
                            pickupAddress.isBlank() || deliveryAddress.isBlank()
                        if (!customerSignedIn) {
                            formError = true
                            submissionMessage = if (arabic) "سجّل دخولك أو أنشئ حساباً أولاً." else "Please sign in or create an account first."
                        } else if (!formError) showOrderPreview = true
                    },
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    enabled = customerSignedIn,
                    colors = ButtonDefaults.buttonColors(containerColor = Orange),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(if (arabic) "اطلب التوصيل" else "Request delivery",
                        color = Color(0xFF090909), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Text(
                    if (arabic) "DEF Delivery • عاليه • بعبدا • بيروت • الشوف"
                    else "DEF Delivery • Aley • Baabda • Beirut • Shouf",
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                    color = Color(0xFFBDBDBD), fontSize = 12.sp
                )
                Text(
                    if (submissionMessage.isNotBlank()) submissionMessage
                    else if (arabic) "سيتم إرسال طلبك وحفظه بأمان عند التأكيد."
                    else "Your request will be securely saved when you confirm.",
                    modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                    color = Color(0xFFBDBDBD), fontSize = 11.sp
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (arabic) "طلباتي السابقة" else "My previous orders",
                            color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp
                        )
                        Text(
                            if (arabic) "اعرض الطلبات المرتبطة بهذه الجلسة وحالة كل طلب."
                            else "View orders saved to your customer account and their current status.",
                            color = Color(0xFFBDBDBD), fontSize = 12.sp
                        )
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isLoadingHistory,
                            onClick = {
                                val uid = FirebaseAuth.getInstance().currentUser?.uid
                                if (uid == null) {
                                    historyMessage = if (arabic) "ما في طلبات محفوظة بهالجلسة بعد."
                                        else "No orders are saved in this session yet."
                                    orderHistory = emptyList()
                                } else {
                                    isLoadingHistory = true
                                    historyMessage = ""
                                    FirebaseFirestore.getInstance()
                                        .collection("deliveryRequests")
                                        .whereEqualTo("ownerUid", uid)
                                        .get()
                                        .addOnSuccessListener { snapshot ->
                                            orderHistory = snapshot.documents.map { doc ->
                                                mapOf(
                                                    "number" to doc.id.takeLast(6).uppercase(),
                                                    "service" to (doc.getString("service") ?: ""),
                                                    "area" to (doc.getString("area") ?: ""),
                                                    "fee" to (doc.getString("deliveryFee") ?: ""),
                                                    "status" to (doc.getString("status") ?: "pending")
                                                )
                                            }.reversed()
                                            isLoadingHistory = false
                                            historyMessage = if (orderHistory.isEmpty()) {
                                                if (arabic) "ما عندك طلبات سابقة." else "No previous orders found."
                                            } else ""
                                        }
                                        .addOnFailureListener { error ->
                                            isLoadingHistory = false
                                            historyMessage = if (arabic) {
                                                "تعذّر تحميل الطلبات: ${error.localizedMessage ?: "خطأ"}"
                                            } else {
                                                "Could not load orders: ${error.localizedMessage ?: "Error"}"
                                            }
                                        }
                                }
                            }
                        ) {
                            Text(
                                if (isLoadingHistory) {
                                    if (arabic) "جارٍ التحميل..." else "Loading..."
                                } else {
                                    if (arabic) "تحديث طلباتي" else "Refresh my orders"
                                }
                            )
                        }
                        if (historyMessage.isNotBlank()) {
                            Text(historyMessage, color = Color(0xFFBDBDBD), fontSize = 12.sp)
                        }
                        orderHistory.forEach { order ->
                            Divider(color = Pale)
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                    Text(
                                        (if (arabic) "طلب #" else "Order #") + order["number"].orEmpty(),
                                        color = Navy, fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        (order["service"].orEmpty()) + " • " + order["area"].orEmpty(),
                                        color = Color(0xFFBDBDBD), fontSize = 11.sp
                                    )
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(order["fee"].orEmpty(), color = Orange, fontWeight = FontWeight.Bold)
                                    Text(
                                        when (order["status"]) {
                                            "pending" -> if (arabic) "قيد الانتظار" else "Pending"
                                            "accepted" -> if (arabic) "تم القبول" else "Accepted"
                                            "picked_up" -> if (arabic) "تم الاستلام" else "Picked up"
                                            "on_the_way" -> if (arabic) "بالطريق" else "On the way"
                                            "delivered" -> if (arabic) "تم التوصيل" else "Delivered"
                                            "cancelled" -> if (arabic) "ملغي" else "Cancelled"
                                            else -> order["status"].orEmpty()
                                        },
                                        color = Color(0xFFDDDDDD), fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                }
            }
            if (showOrderPreview) {
                AlertDialog(
                    onDismissRequest = { showOrderPreview = false },
                    title = { Text(if (arabic) "مراجعة الطلب" else "Review your request") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(if (arabic) "الاسم: $customerName" else "Name: $customerName")
                            Text(if (arabic) "الهاتف: $customerPhone" else "Phone: $customerPhone")
                            Text(if (arabic) "الخدمة: ${if (arabic) services[selectedService].ar else services[selectedService].en}"
                                else "Service: ${services[selectedService].en}")
                            Text(if (arabic) "المنطقة: ${areas[selectedArea].ar}" else "Area: ${areas[selectedArea].en}")
                            Text(if (arabic) "الاستلام: $pickupAddress" else "Pickup: $pickupAddress")
                            Text(if (arabic) "التوصيل: $deliveryAddress" else "Delivery: $deliveryAddress")
                            Text(if (arabic) "رسوم التوصيل: ${areas[selectedArea].price}"
                                else "Delivery fee: ${areas[selectedArea].price}")
                            if (orderNotes.isNotBlank()) Text(if (arabic) "ملاحظات: $orderNotes" else "Notes: $orderNotes")
                            Text(
                                if (arabic) "راجعي التفاصيل ثم أكّدي لإرسال الطلب."
                                else "Review your details, then confirm to send the request.",
                                color = Orange, fontWeight = FontWeight.Bold
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(
                            enabled = !isSaving,
                            onClick = {
                                isSaving = true
                                submissionMessage = ""
                                val auth = FirebaseAuth.getInstance()
                                val saveRequest: (String) -> Unit = { uid ->
                                    val order = hashMapOf<String, Any>(
                                        "ownerUid" to uid,
                                        "customerName" to customerName.trim(),
                                        "customerPhone" to customerPhone.trim(),
                                        "service" to services[selectedService].en,
                                        "area" to areas[selectedArea].en,
                                        "deliveryFee" to areas[selectedArea].price,
                                        "pickupAddress" to pickupAddress.trim(),
                                        "deliveryAddress" to deliveryAddress.trim(),
                                        "notes" to orderNotes.trim(),
                                        "status" to "pending",
                                        "createdAt" to FieldValue.serverTimestamp()
                                    )
                                    FirebaseFirestore.getInstance()
                                        .collection("deliveryRequests")
                                        .add(order)
                                        .addOnSuccessListener {
                                            isSaving = false
                                            showOrderPreview = false
                                            submissionMessage = if (arabic) "تم إرسال طلبك وحفظه بنجاح!" else "Your request was sent and saved successfully!"
                                        }
                                        .addOnFailureListener { error ->
                                            isSaving = false
                                            submissionMessage = if (arabic) "تعذّر حفظ الطلب: ${error.localizedMessage ?: "خطأ غير معروف"}" else "Could not save request: ${error.localizedMessage ?: "Unknown error"}"
                                        }
                                }
                                val currentUser = auth.currentUser
                                if (currentUser != null && currentUser.emailVerified &&
                                    !currentUser.email.equals("halimehhalimeh669@gmail.com", ignoreCase = true)) {
                                    saveRequest(currentUser.uid)
                                } else {
                                    isSaving = false
                                    submissionMessage = if (arabic) "سجّل دخولك بحساب زبون مؤكّد أولاً." else "Please sign in with a verified customer account first."
                                }
                            }
                        ) {
                            Text(if (isSaving) { if (arabic) "جارٍ الإرسال..." else "Sending..." }
                                else { if (arabic) "تأكيد وإرسال الطلب" else "Confirm & send request" })
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showOrderPreview = false }) {
                            Text(if (arabic) "تعديل" else "Edit")
                        }
                    }
                )
            }
        }
    }
}



@Composable
private fun CustomerAccountPanel(
    arabic: Boolean,
    signedIn: Boolean,
    onSignedIn: () -> Unit,
    onSignOut: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var fullName by remember { mutableStateOf("") }
    var createMode by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val auth = FirebaseAuth.getInstance()

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)),
        shape = RoundedCornerShape(20.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                if (signedIn) {
                    if (arabic) "حساب الزبون" else "Customer account"
                } else {
                    if (arabic) "حساب الزبون" else "Customer account"
                },
                color = Navy, fontWeight = FontWeight.Bold, fontSize = 18.sp
            )
            if (signedIn) {
                Text(auth.currentUser?.email.orEmpty(), color = Color.White)
                Text(
                    if (arabic) "حسابك جاهز لاستقبال طلباتك وحفظها." else "Your account is ready to place and track orders.",
                    color = Color(0xFFBDBDBD), fontSize = 12.sp
                )
                OutlinedButton(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
                    Text(if (arabic) "تسجيل الخروج" else "Sign out")
                }
            } else {
                if (createMode) {
                    OutlinedTextField(
                        value = fullName, onValueChange = { fullName = it },
                        label = { Text(if (arabic) "الاسم الكامل" else "Full name") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                }
                OutlinedTextField(
                    value = email, onValueChange = { email = it },
                    label = { Text(if (arabic) "البريد الإلكتروني" else "Email") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true
                )
                OutlinedTextField(
                    value = password, onValueChange = { password = it },
                    label = { Text(if (arabic) "كلمة المرور" else "Password") },
                    modifier = Modifier.fillMaxWidth(), singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                if (createMode) {
                    OutlinedTextField(
                        value = confirmPassword, onValueChange = { confirmPassword = it },
                        label = { Text(if (arabic) "تأكيد كلمة المرور" else "Confirm password") },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        visualTransformation = PasswordVisualTransformation()
                    )
                }
                Button(
                    enabled = !loading,
                    onClick = {
                        message = ""
                        if (email.isBlank() || password.length < 6 ||
                            (createMode && (fullName.isBlank() || password != confirmPassword))) {
                            message = if (arabic) "تأكد من البيانات. كلمة المرور يجب أن تكون 6 أحرف على الأقل." else "Check your details. Password must be at least 6 characters."
                        } else {
                            loading = true
                            if (createMode) {
                                auth.createUserWithEmailAndPassword(email.trim(), password)
                                    .addOnSuccessListener { result ->
                                        val user = result.user
                                        if (user == null) {
                                            loading = false
                                            message = if (arabic) "تعذّر إنشاء الحساب." else "Could not create account."
                                        } else {
                                            user.sendEmailVerification().addOnCompleteListener { task ->
                                                auth.signOut()
                                                loading = false
                                                message = if (task.isSuccessful) {
                                                    if (arabic) "أنشأنا حسابك! افتح رسالة التأكيد على بريدك، ثم سجّل الدخول." else "Account created! Verify your email, then sign in."
                                                } else {
                                                    task.exception?.localizedMessage ?: "Could not send verification email."
                                                }
                                                createMode = false
                                                password = ""
                                                confirmPassword = ""
                                            }
                                        }
                                    }
                                    .addOnFailureListener {
                                        loading = false
                                        message = it.localizedMessage ?: "Registration failed."
                                    }
                            } else {
                                auth.signInWithEmailAndPassword(email.trim(), password)
                                    .addOnSuccessListener { result ->
                                        val user = result.user
                                        if (user?.isEmailVerified == true &&
                                            !user.email.equals("halimehhalimeh669@gmail.com", ignoreCase = true)) {
                                            loading = false
                                            onSignedIn()
                                        } else {
                                            user?.sendEmailVerification()?.addOnCompleteListener {
                                                auth.signOut()
                                                loading = false
                                                message = if (arabic) "أكد بريدك الإلكتروني من الرسالة ثم حاول مجدداً." else "Verify your email from the message, then try again."
                                            } ?: run {
                                                auth.signOut()
                                                loading = false
                                                message = if (arabic) "هذا الحساب غير صالح للزبائن." else "This account cannot be used as a customer account."
                                            }
                                        }
                                    }
                                    .addOnFailureListener {
                                        loading = false
                                        message = it.localizedMessage ?: "Sign-in failed."
                                    }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange)
                ) {
                    Text(
                        if (loading) {
                            if (arabic) "يرجى الانتظار..." else "Please wait..."
                        } else if (createMode) {
                            if (arabic) "إنشاء حساب" else "Create account"
                        } else {
                            if (arabic) "تسجيل الدخول" else "Sign in"
                        },
                        color = Color.Black, fontWeight = FontWeight.Bold
                    )
                }
                TextButton(onClick = {
                    createMode = !createMode
                    message = ""
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        if (createMode) {
                            if (arabic) "عندي حساب — تسجيل الدخول" else "I already have an account — Sign in"
                        } else {
                            if (arabic) "ما عندي حساب — إنشاء حساب جديد" else "New customer? Create an account"
                        },
                        color = Navy
                    )
                }
                if (!createMode) {
                    TextButton(
                        enabled = !loading && email.isNotBlank(),
                        onClick = {
                            loading = true
                            auth.sendPasswordResetEmail(email.trim())
                                .addOnCompleteListener { task ->
                                    loading = false
                                    message = if (task.isSuccessful) {
                                        if (arabic) "إذا كان البريد مسجلاً، ستصلك رسالة لإعادة تعيين كلمة المرور." else "If the email is registered, a password reset link will be sent."
                                    } else {
                                        task.exception?.localizedMessage ?: "Could not send reset email."
                                    }
                                }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (arabic) "نسيت كلمة المرور؟" else "Forgot password?", color = Color(0xFFBDBDBD))
                    }
                }
                if (message.isNotBlank()) {
                    Text(message, color = Color(0xFFFFD700), fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun AdminDashboard(
    arabic: Boolean,
    email: String,
    onEmailChange: (String) -> Unit,
    password: String,
    onPasswordChange: (String) -> Unit,
    message: String,
    loading: Boolean,
    orders: List<Map<String, String>>,
    onLogin: () -> Unit,
    onRefresh: () -> Unit,
    onStatusChange: (String, String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(if (arabic) "لوحة إدارة الطلبات" else "Admin orders dashboard",
            color = Navy, fontSize = 23.sp, fontWeight = FontWeight.Black)
        if (FirebaseAuth.getInstance().currentUser?.email.equals("halimehhalimeh669@gmail.com", ignoreCase = true)
            && FirebaseAuth.getInstance().currentUser?.isEmailVerified == true) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (arabic) "كل الطلبات الواردة" else "All incoming orders", color = Navy, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = onRefresh, enabled = !loading) {
                    Text(if (loading) { if (arabic) "تحميل..." else "Loading..." }
                         else { if (arabic) "تحديث" else "Refresh" })
                }
            }
            if (orders.isEmpty() && message.isBlank()) Text(if (arabic) "اضغط تحديث لعرض الطلبات." else "Tap refresh to load orders.", color = Color(0xFFBDBDBD))
            orders.forEach { order ->
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171717)), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text((if (arabic) "طلب #" else "Order #") + order["id"].orEmpty().takeLast(6).uppercase(), color = Navy, fontWeight = FontWeight.Bold)
                        Text((if (arabic) "الاسم: " else "Name: ") + order["name"].orEmpty())
                        Text((if (arabic) "الهاتف: " else "Phone: ") + order["phone"].orEmpty())
                        Text((if (arabic) "الخدمة: " else "Service: ") + order["service"].orEmpty())
                        Text((if (arabic) "المنطقة: " else "Area: ") + order["area"].orEmpty() + " • " + order["fee"].orEmpty())
                        Text((if (arabic) "الاستلام: " else "Pickup: ") + order["pickup"].orEmpty())
                        Text((if (arabic) "التوصيل: " else "Delivery: ") + order["delivery"].orEmpty())
                        if (order["notes"].orEmpty().isNotBlank()) Text((if (arabic) "ملاحظات: " else "Notes: ") + order["notes"].orEmpty())
                        Text((if (arabic) "الحالة: " else "Status: ") + order["status"].orEmpty(), color = Orange, fontWeight = FontWeight.Bold)
                        Text(if (arabic) "تغيير الحالة" else "Update status", color = Navy, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                            listOf("accepted", "picked_up", "on_the_way", "delivered", "cancelled").forEach { status ->
                                TextButton(onClick = { onStatusChange(order["id"].orEmpty(), status) }, contentPadding = PaddingValues(horizontal = 5.dp, vertical = 2.dp)) {
                                    Text(when (status) {
                                        "accepted" -> if (arabic) "قبول" else "Accept"
                                        "picked_up" -> if (arabic) "استلام" else "Picked"
                                        "on_the_way" -> if (arabic) "بالطريق" else "On way"
                                        "delivered" -> if (arabic) "تم" else "Done"
                                        else -> if (arabic) "إلغاء" else "Cancel"
                                    }, fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Text(if (arabic) "تسجيل دخول الأدمن" else "Admin sign in", color = Navy, fontWeight = FontWeight.Bold)
            OutlinedTextField(value = email, onValueChange = onEmailChange,
                label = { Text(if (arabic) "البريد الإلكتروني" else "Email address") },
                modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = password, onValueChange = onPasswordChange,
                label = { Text(if (arabic) "كلمة المرور" else "Password") },
                modifier = Modifier.fillMaxWidth(), singleLine = true,
                visualTransformation = PasswordVisualTransformation())
            Button(onClick = onLogin, enabled = !loading, modifier = Modifier.fillMaxWidth()) {
                Text(if (loading) { if (arabic) "جارٍ الدخول..." else "Signing in..." }
                     else { if (arabic) "دخول" else "Sign in" })
            }
            Text(if (arabic) "الدخول مسموح فقط لحساب الإدارة الموثّق." else "Only the verified admin account can access orders.", color = Color(0xFFBDBDBD), fontSize = 12.sp)
        }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
    }
}

@Composable
private fun SectionTitle(value: String) {
    Text(value, color = Navy, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun SelectableRow(
    title: String, subtitle: String, trailing: String, selected: Boolean, onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF30280F) else Color(0xFF171717)),
        border = if (selected) androidx.compose.foundation.BorderStroke(1.5.dp, Orange) else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(15.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, color = Navy, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, color = Color(0xFFBDBDBD), fontSize = 12.sp)
            }
            if (trailing.isNotEmpty()) Text(trailing, color = if (trailing == "✓") Orange else Navy,
                fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
    }
}

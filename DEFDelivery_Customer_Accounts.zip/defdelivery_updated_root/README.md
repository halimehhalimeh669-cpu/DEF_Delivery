# DEF Delivery — Android project

Bilingual Arabic/English Android customer app built with Kotlin and Jetpack Compose.

## Implemented in this source snapshot
- DEF Delivery branding and Arabic RTL / English LTR language toggle.
- Delivery categories: restaurants and food, shopping and general errands, parcels and other items.
- Fixed delivery fees: Aley & Aley District $1.50; Baabda & Baabda District $3.00; Beirut $4.00.
- Customer delivery-request form with required-field validation and a review-before-submit dialog.
- Firebase Anonymous Authentication session and Cloud Firestore order creation (`pending`).
- Customer order-history refresh, showing each saved request and its current status.
- Firestore create validation for allowed services, exact area/fee pairs, bounded text fields, and owner UID; customers can read only their own requests.

## Firebase owner setup still required
1. In Firebase Console for `def-delivery`, enable Authentication > Sign-in method > Anonymous.
2. Create Cloud Firestore in Production mode.
3. Publish the included `firestore.rules` rules.
4. Confirm the Android app's Firebase configuration is the correct one for the owner's Firebase project.

Until the Firebase steps are completed, order submission and order-history retrieval will not work against the live backend.

## Important limitations — not implemented or verified
- No permanent email/phone customer accounts; current identity is an anonymous installation session.
- No driver account, driver assignment, admin dashboard, dispatch workflow, or authorized order-status updates.
- No maps, live location tracking, push notifications, online payments, or automated delivery routing.
- No release signing key, signed APK/AAB, Play Console submission, or publication.

The Firestore rules intentionally deny all order updates/deletes until driver/admin roles are designed and protected by verified authentication claims. Do not loosen these rules for convenience.

## Build and release
Open this folder in Android Studio and sync Gradle. Run unit tests and install a debug build on physical devices. Configure release signing with an upload key controlled by the app owner, then generate a signed Android App Bundle (AAB). Complete Play Console testing, store listing, privacy policy, Data safety, and all applicable declarations before publishing.
